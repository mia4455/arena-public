# Project Structure Template

```
project/
├─ src/
│  ├─ index.ts                 # registerRoot(RemotionRoot)
│  ├─ Root.tsx                  # <Composition id="Main" .../>
│  ├─ theme.ts                  # templates/theme.ts থেকে (রং/ফন্ট/easing/spring/tokens)
│  ├─ data/
│  │  ├─ timeline.ts            # SRT→frame map (SRT থাকলে), নইলে audio/estimated timing
│  │  └─ tutorialState.ts       # tutorial steps (Annex G §3)
│  ├─ scenes/
│  │  ├─ Scene01_Hook.tsx
│  │  ├─ Scene02_Context.tsx
│  │  └─ ...
│  └─ components/
│     ├─ text/                  # WordReveal, LineMaskRise, Counter, presets (Annex B)
│     ├─ icons/                 # inline SVG icons (Annex C)
│     ├─ ui/                    # cards, panels, charts, browser/phone mockup
│     ├─ photo/                 # KenBurns, MaskReveal, treatments (Annex D)
│     ├─ tutorial/              # Cursor, ClickRipple, StepChip, HighlightBox (Annex G)
│     ├─ transitions/           # WhipPan, MaskWipe, ScaleThrough (Annex E)
│     └─ post/                  # BgMesh, Grade, Grain, Vignette (Annex H §4–7)
├─ public/
│  ├─ images/                   # সব ছবি (stock/AI/user)
│  ├─ logos/                    # ইউজারের লোগো (আসল ফাইল, বিকৃত নয়)
│  ├─ ui-refs/                  # tutorial screenshot/reference
│  ├─ fonts/                    # licensed local font files (Hind Siliguri, Noto Sans Bengali...)
│  ├─ sfx/                      # whoosh_soft_01.wav, click_crisp_01.wav ... (Annex I)
│  └─ voiceover.mp3             # (ঐচ্ছিক) — থাকলে PreviewAudio বাজবে
├─ out/                         # render output (video.mp4, check_*.png)
├─ ASSETS.md                    # প্রতিটি asset-এর source + license + AI-generated না কিনা
├─ README.md                    # Windows PowerShell: install / studio / render / error handling
├─ package.json                 # "render" script সত্যিকারের Main composition-এ যুক্ত
└─ tsconfig.json
```

## Naming conventions
- Composition ID: `Main` (ইউজার ভিন্ন না বললে)
- Scene files: `Scene01_Hook.tsx`, `Scene02_...` (ক্রম সংখ্যা + ভূমিকা)
- SFX: `public/sfx/<type>_<mood>_01.wav`
- Check frames: `out/check_<frame>.png`

## package.json scripts (উদাহরণ)
```json
{
  "scripts": {
    "studio": "remotion studio src/index.ts",
    "render": "remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17",
    "still": "remotion still src/index.ts Main out/check.png --overwrite"
  }
}
```
entry ফাইলের আসল নাম অনুযায়ী command মিলিয়ে নেবে — placeholder রাখবে না।

### Dependencies ও reproducibility
- `package.json`-এ `remotion` ও `@remotion/cli` একই নির্দিষ্ট version-এ pin করবে; `react`/`react-dom` Remotion-এর সমর্থিত version range-এ রাখবে। TypeScript project-এ `typescript`, `@types/react` ও প্রয়োজনমতো `@types/node` যোগ করবে।
- `package-lock.json` project ZIP-এ রাখবে। প্রথম install-এ `npm install`; lockfile থাকা delivered project-এ `npm ci` ব্যবহার করবে। Optional `@remotion/*` package-ও core version-এর সঙ্গে সামঞ্জস্যপূর্ণ হতে হবে।

### Local font loading (offline)
Font license অনুমতি দিলে font file `public/fonts/`-এ রাখো এবং CSS-এ নাম/weight নির্দিষ্ট করে load করো; উদাহরণ:
```css
@font-face {
  font-family: "Hind Siliguri";
  src: url("/fonts/HindSiliguri-Regular.ttf") format("truetype");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
}
```
CSS-টি entry থেকে import করবে। Bold/অন্য weight-এর আলাদা file থাকলে আলাদা `@font-face` দেবে। Font file project-এ না থাকলে system fallback ব্যবহার করে limitation জানাবে—font load সম্পন্ন হয়েছে বলে দাবি করবে না।

## Composition config (Root.tsx)
```tsx
<Composition
  id="Main"
  component={Main}
  durationInFrames={timeline.total}   // SRT থাকলে শেষ cue; নইলে audio/estimated duration (+ outro)
  fps={30}
  width={1920}
  height={1080}
/>
```
- রিল/শর্ট: width 1080, height 1920
- 60fps: ইউজার চাইলে বা খুব দ্রুত মোশনে — সব animation frame-based বলে স্কেল হবে
- `durationInFrames` ↔ scene content মিলবে — SRT থাকলে শেষ cue, audio থাকলে audio duration, অন্যথায় ঘোষিত estimate অনুযায়ী; অপ্রয়োজনীয় dead air নয়
