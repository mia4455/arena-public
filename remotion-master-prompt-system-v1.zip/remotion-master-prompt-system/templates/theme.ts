// theme.ts — প্রতিটি Remotion প্রজেক্টের single source of truth.
// কোম্পোনেন্টে কখনো inline color/easing/spring নয় — সব এখান থেকে।
import { Easing } from "remotion";

export const theme = {
  colors: {
    // User-এর নির্বাচিত color scheme (ধাপ ৩) অনুযায়ী বসাও। ডিফল্ট: emerald/dark-tech identity.
    bg: "#07120D",          // base (60%)
    bgAlt: "#0C1A13",       // secondary surfaces (30%)
    surface: "#12241B",     // cards/panels
    primary: "#10B981",     // HERO color (emerald) — প্রতি ফ্রেমে সর্বোচ্চ 1 element
    accent: "#A3E635",      // lime accent (10%)
    text: "#F0FDF4",        // off-white
    textDim: "#94A3B8",     // gray tone
    glow: "rgba(16, 185, 129, 0.4)",
    danger: "#EF4444",      // শুধু error/status (tutorial "করবেন না" ইত্যাদি)
    success: "#22C55E",     // শুধু status (সফল) — সবসময় লেবেল সহ
  },
  fonts: {
    display: "Hind Siliguri",       // বাংলা+EN hero (fallback: Noto Sans Bengali)
    body: "Noto Sans Bengali",      // fallback: Hind Siliguri, system-ui
    mono: "JetBrains Mono",         // code/number (Latin)
    // fallback chain: [display, "Noto Sans Bengali", "Baloo Da 2", "Anek Bangla", "system-ui"]
  },
  // THE easing curves — linear নিষিদ্ধ।
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),      // easeOutExpo — entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1),   // easeInOutQuint — moves, Ken Burns
    in: Easing.bezier(0.7, 0, 0.84, 0),       // exits only
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },  // UI pops, শব্দ
    smooth: { damping: 20, stiffness: 90, mass: 1 },     // বড় element
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },  // playful accent, লোগো, আইকন
  },
  // Typography tokens (Annex B §4) — বাংলায় lineHeight 1.25–1.4; letterSpacing 0
  textStyles: {
    h1: { fontFamily: "display", fontWeight: 800, fontSize: 120, lineHeight: 1.3 },
    h2: { fontFamily: "display", fontWeight: 700, fontSize: 64, lineHeight: 1.35 },
    eyebrow: { fontFamily: "body", fontWeight: 600, fontSize: 22 },
    label: { fontFamily: "body", fontWeight: 500, fontSize: 18 },
    chip: { fontFamily: "body", fontWeight: 600, fontSize: 16 },
    bigNumber: { fontFamily: "mono", fontWeight: 700, fontVariantNumeric: "tabular-nums" },
    uiText: { fontFamily: "body", fontWeight: 500, fontSize: 14 },
    caption: { fontFamily: "body", fontWeight: 500, fontSize: 16 },
  },
  radii: { sm: 8, md: 16, lg: 24, xl: 32, pill: 999 },
  shadows: {
    card: "0 40px 80px -20px rgba(0,0,0,0.6)",
    glowHero: "0 0 60px rgba(16, 185, 129, 0.4), 0 0 120px rgba(16, 185, 129, 0.2)",
  },
} as const;
