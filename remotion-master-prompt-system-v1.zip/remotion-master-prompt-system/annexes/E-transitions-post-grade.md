# Annex E — Transitions, Backgrounds ও Post/Grade স্ট্যাক

## ১. Transition লাইব্রেরি

প্রতিটি **8–14 frame @30fps** (60fps-এ frame count স্কেল করো)।

| ট্রানজিশন | প্রকার | কীভাবে | কোথায় |
|---|---|---|---|
| **Cut (on beat)** | ফ্রি | সরাসরি cut | দ্রুত পেসিং |
| **Slide/Wipe** | shape | প্যানেল স্লাইড, পরের সিন ঢেকে আসে | সাধারণ |
| **Whip Pan + blur** | ক্যামেরা | bg 1500px/6f + blur(8px), মাঝে cut | এনার্জেটিক |
| **Zoom Blur / Scale-through** | ক্যামেরা | A scale→1.3+fade, B 0.8→1 নিচে | হুক→বডি |
| **Mask Shape Wipe** | shape | hero-color আকৃতি (circle/blob/arrow) সুইপ, পেছনে cut | ব্র্যান্ডেড |
| **Light Leak / Flash** | আলো | হালকা আলোর ঝলক + fade | ইমোশনাল শিফট |
| **Glitch Cut / RGB split** | টেক | 5–8f slice + RGB shift | ডেভ/টেক |
| **Split Panel** | layout | ২–৩ স্লাইস ভিন্ন দিকে স্লাইড | তালিকা→তালিকা |
| **Letterbox Bars** | সিনেমা | কালো বার উপর/নিচ থেকে আসে, মাঝে cut | চ্যাপ্টার শিফট |
| **Ink/Liquid** | shape morph | organic blob morph | ক্রিয়েটিভ |
| **Match Cut** | আকৃতি/রং | এক সিনের আকৃতি পরের সিনে মিলে যায় | স্মার্ট সংযোগ |
| **Crossfade** | opacity | 12–18f fade | শুধু ধীর/সংবেদনশীল মুহূর্ত |

**প্যাকেজ ব্যবহার:** `@remotion/transitions` (`TransitionSeries`, `slide`, `fade`, `wipe` + `linearTiming`) — বা hand-rolled (Annex H §14)।

### সিলেকশন নিয়ম
- পরপর একই ট্রানজিশন **নয়**; ১ মিনিটে ২–৪টি স্টাইল যথেষ্ট।
- **Tutorial-এ:** ধাপ পরিবর্তনে সাধারণ cut/slide; ইন্টার‌্যাকশন দেখানোর সময় কোনো ট্রানজিশন যেন UI state ঢাকে না।
- ট্রানজিশন সবসময় বক্তব্যের অর্থ সহায়তা করবে — "এফেক্ট দেখানোর" জন্য নয়।
- ট্রানজিশনের সময় দর্শকের মনোযোগের জায়গা বদলাবে — একই দিকে তাকিয়ে রাখা সিনে শুধু cut ভালো।

## ২. Background সিস্টেম (ফ্ল্যাট নয়)

প্রতি সিনে নিচের কাঠামো (Annex H §4 BgMesh + বৈচিত্র্য):

- **Gradient mesh / soft orbs** — ধীর sin-wave drift (bg-এ ১–২টি blurred orb)
- **Technical grid / dots / connected lines** — টেক সিনে (opacity ≤0.15)
- **Geometric pattern / thin outlines** — subtle, অ্যানিমেটেড draw-on
- **Split composition** — দুই অংশে ভিন্ন tone
- **Layered panels** — সামনে/পেছনে স্তর (depth)
- **Clean light / dark cinematic** — বিষয় অনুযায়ী

**নিয়ম:** background মূল বিষয়কে সাহায্য করবে, ঢাকবে না। অকারণে একই background পুনরাবৃত্তি নয়; তবে visual identity একই। সব সিনে ৫-লেয়ার স্ট্যাক বাধ্যতামূলক: **background mesh → assets → graphics/type → grade → grain+vignette**।

## ৩. Post/Grade Finishing Pass (সব সিনে একরকম — এটাই identity)

**স্থির ক্রম (নিচ থেকে উপরে):**

1. **Color grade overlay** — hero color `soft-light` (dark theme: 0.18–0.25, light: 0.10–0.15) + উপর/নিচে হালকা vignette gradient
2. **Chromatic aberration** — খুব হালকা (কিনারায় 1–2px RGB split), শুধু দ্রুত মুভ/ইমপ্যাক্ট মুহূর্তে
3. **Bloom/Glow** — শুধু hero element-এ (`boxShadow: 0 0 60px hero66, 0 0 120px hero33`; text-এ `textShadow`)। প্রতি ফ্রেমে ১টির বেশি glowing element = Vegas — নয়
4. **Vignette** — radial, transparent 56% → black 22% (Annex H §7)
5. **Grain** — procedural SVG noise, 5% opacity, film flicker (Annex H §6)
6. **ঐচ্ছিক texture** — scanlines/halftone/paper (বিষয় অনুযায়ী একটি, খুব subtle)

**Asset mismatch correction:** একটি ছবি/ক্লিপ স্টিক আউট করলে per-asset `filter: "saturate(1.1) contrast(1.08)"` — সবগুলোতে নয়।

## ৪. Atmosphere Elements (সংযতে)

| Element | সীমা | কখন |
|---|---|---|
| Floating dust/bokeh particles | 10–20টি, opacity 0.1–0.3 | depth লাগলে |
| Light sweep | কার্ড/টেক্সটের উপর আলোর ঝলক 8–12f | hero reveal |
| Light leak | খুব হালকা | সিন ট্রানজিশন |
| Network nodes + lines | ধীর ড্র | কানেকশন/টেক |
| Liquid blob morph | bg-এ ধীর (sin/cos) | creative সিন |
| Wireframe globe/cube | CSS 3D ধীর ঘূর্ণন | গ্লোবাল/টেক |

এক ফ্রেমে একাধিক atmosphere effect নয়। particle কখনো টেক্সট/UI-কে অস্পষ্ট করবে না।
