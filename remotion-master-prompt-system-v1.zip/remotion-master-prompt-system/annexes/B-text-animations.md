# Annex B — টেক্সট অ্যানিমেশন প্রিসেট লাইব্রেরি (After Effects-মানের)

> প্রতিটি প্রিসেটের spec মেনে ব্যবহার করবে। প্রতি সিনে ১টি primary + ১টি secondary টেক্সট মোশন যথেষ্ট। একই প্রিসেট ৩+ বার টানাটানি নয়। সব animation deterministic (frame-based), `fps` থেকে সময়।

## ১. Preset Library (২২টি)

| প্রিসেট | কখন | কী অ্যানিমেট হয় | ~সময় (30fps) | Easing/Spring | Bangla |
|---|---|---|---|---|---|
| **Title Slam** | হুক/বড় শিরোনাম | scale 1.15→1, opacity 0→1, blur 2→0 | 14–18f | spring snappy | ✅ |
| **Eyebrow Track-In** | ছোট label/উপরের লাইন | opacity, y −8→0, letterSpacing 0.4→0 (শুধু EN) | 16f | ease.out | ✅ (বাংলায় tracking নয়) |
| **Word Cascade** | মাঝারি হেডলাইন | শব্দ ধরে stagger: y +24→0 + opacity | 3f/শব্দ | spring snappy | ✅ space-split |
| **Line Mask Rise** | বড় বাক্য | লাইন ধরে clip-path মাস্ক + y স্লাইড | 8f/লাইন | ease.out | ✅ |
| **Highlight Sweep** | গুরুত্বপূর্ণ শব্দ | পেছনে pill/underline বাঁ→ডান সুইপ | 12f | ease.inOut | ✅ |
| **Gradient Flow Text** | কীওয়ার্ড | animated gradient fill (background-clip: text) | ধীর লুপ | linear (gradient only) | ✅ |
| **Blur Focus Pull** | স্টেটমেন্ট | blur 12→0 + scale 1.06→1 + opacity | 18–22f | ease.out | ✅ |
| **3D Word Flip** | তালিকা আইটেম | rotateX(−80→0), perspective 800px, opacity | 12f/শব্দ | spring smooth | ✅ শব্দ ধরে |
| **Split & Reassemble** | টুল/ফিচার নাম | ২ অংশ স্লাইড করে মিল | 20f | ease.inOut | ✅ শব্দ/phrase ধরে |
| **Odometer Roll** | সংখ্যা/stat | ডিজিট স্লট-মেশিন roll, `tabular-nums` | 25–40f | spring smooth | ✅ |
| **Counter Count-Up** | শতাংশ/গণনা | interpolate + suffix (স্ক্রিপ্টের সংখ্যাই — কল্পিত নয়) | 30–45f | ease.out | ✅ |
| **Typewriter + Caret** | শুধু চ্যাট/সার্চ/টার্মিনাল UI | শব্দ ধরে মাস্ক-টাইপ + ব্লিংক কার্সর | কনটেন্ট অনুযায়ী | steps | ✅ শব্দ ধরে |
| **RGB Split Impact** | ইমপ্যাক্ট (১–২বার) | R/G/B লেয়ার অফসেট 3–6px → মিল | 6–8f | ease.out | ✅ |
| **Echo Trail Text** | স্পিড/মোশন বোঝাতে | 3–4টি ডিম কপি ট্রেইল | 10f | ease.out | ✅ |
| **Stroke Draw Text** | টেকনিক্যাল শিরোনাম | SVG stroke-dashoffset draw-on (fallback: fill reveal) | 25–35f | ease.inOut | ⚠️ fallback সহ |
| **Text Window** | ছবি দেখাতে | টেক্সটের ভেতর ছবি/ভিডিও (background-clip: text) + ধীর pan | ধীর | ease.inOut | ✅ |
| **Kinetic Stack** | পোস্টার-স্টাইল হুক | লাইন স্ট্যাক, এক লাইন স্লাইড, একটি স্থির | 18f | ease.out | ✅ |
| **Quote Reveal** | উদ্ধৃতি | বড় কোটেশন মার্ক draw + লাইন রিভিল | 30f | spring smooth | ✅ |
| **Marquee Strip** | ট্যাগ/কীওয়ার্ড স্ট্রিপ | ধীর infinite marquee (পড়ার গতি) | লুপ | linear (পজিশন) | ✅ |
| **Scramble Decode** | শুধু ইংরেজি টেকনিক্যাল শব্দ | অক্ষর ঘুরিয়ে ডিকোড | 20f | steps | ❌ বাংলায় নয় |
| **Glitch Flicker** | ডেভ/টেক সিন (সীমিত) | opacity slice + RGB shift | 5–8f | steps | ✅ সংযতে |
| **Word Pop (Bounce)** | ছোট অ্যাকসেন্ট | scale 0.7→1.08→1 | 10f | spring bouncy | ✅ |

**নিয়ম:** প্রতিটি টেক্সট এন্ট্রান্সে অন্তত ২টি প্রপার্টি (opacity + transform)। প্রতি টেক্সট ব্লকের **exit আছে** (৮–১২f, এন্ট্রান্সের চেয়ে দ্রুত): opacity→0 + y/scale ছোট মুভ (Annex H §11)।

## ২. AE Motion Principle → Remotion ম্যাপিং

| নীতি | কীভাবে |
|---|---|
| **Anticipation** | বড় মুভের ৪–৬f আগে বিপরীত ছোট মুভ (scale 0.98, y +4) |
| **Overshoot & Settle** | `spring.snappy` (UI/শব্দ), `spring.smooth` (বড় ব্লক), `spring.bouncy` (খেলোদো অ্যাকসেন্ট) |
| **Follow-through** | মূল ব্লক থামার ৪–৮f পরে secondary element (underline, chip, icon) আসবে |
| **Staging** | প্রতি ফ্রেমে একটিই হিরো মুভ; বাকি স্থির বা micro-motion (sin-wave) |
| **Timing contrast** | HIT → hold (15–20f স্থির পড়ার সময়) → build। দ্রুত মুভ ও স্থিরতার contrast-ই premium দেখায় |
| **Motion hierarchy** | headline > sub > label — সব একসঙ্গে এক গতিতে নয় |

## ৩. বাংলা টেক্সট সেফটি (বাধ্যতামূলক)

1. **কখনো অক্ষর ধরে ভেঙে অ্যানিমেট করবে না** — যুক্তাক্ষর, কার-চিহ্ন, রেফ ভাঙে। সব অ্যানিমেশন **শব্দ/লাইন/phrase** স্তরে।
2. **শব্দ-বিভাজন শুধু space-এ** (`text.split(" ")`)। `word-break: keep-all`। `letterSpacing: 0` (বাংলায় tracking নয়)।
3. **টাইপরাইটার** বাংলায় শব্দ ধরে বা বাঁ→ডানে মাস্ক-সুইপ; অক্ষর ধরে টাইপ নয়।
4. **Scramble/decode, character-flip, stroke-text, letterSpacing animate** — বাংলায় নিষিদ্ধ। ইংরেজি টেকনিক্যাল শব্দে সীমিতভাবে চলবে।
5. **lineHeight:** বাংলা display-এ 1.25–1.4 (কার/ফলার জন্য tight lineHeight বিপজ্জনক)।
6. **মিক্সড বাংলা+English লাইনে baseline align** যাচাই।
7. **ফন্ট:** Hind Siliguri / Noto Sans Bengali / Noto Serif Bengali / Baloo Da 2 / Anek Bangla / Tiro Bangla — বিষয় অনুযায়ী, offline bundle, fallback chain সহ। সর্বোচ্চ ২টি প্রধান family।
8. **Render-পূর্ব টেস্ট স্ট্রিং** (একটি still রেন্ডার করে দেখবে):
   - `ক্ষ ত্র জ্ঞ কৌ শ্রী ৩৯%`
   - `বাংলা ও English baseline টেস্ট — 0123 ০১২৩`
   - দেখবে: যুক্তাক্ষর ভাঙেনি, কার সঠিক জায়গায়, baseline মিল, কোনো glyph missing নয়

## ৪. Typography Tokens (theme.ts-এ)

```
textStyles:
  H1_Slam      : display 80–140px (reels) / 100–160px (landscape), w800, lh 1.2–1.3 (বাংলা)
  H2_Rise      : display 48–72px, w700
  Eyebrow      : body 18–24px, w600, uppercase (EN), letterSpacing 0.4 (EN)
  Label        : body 16–22px, w500, textDim
  Chip/Badge   : body 14–18px, w600, pill background
  BigNumber    : display/mono, w700–800, tabular-nums
  UI_Text      : body 12–16px (mockup ভেতরে)
  Caption      : body 14–18px, w500, textDim
```

- **সংখ্যা নীতি:** ডেটা/টেকনিক্যাল context-এ Latin digits (0–9); বাক্যের ভেতরে বাংলা অঙ্ক (০-৯) চলবে। এক ভিডিওতে একটি নিয়মই মানবে।
- **Highlight নীতি:** এক লাইনে সর্বোচ্চ ১টি শব্দ highlight (hero color / underline / pill)।
- **Safe zone:** টেক্সট কখনো frame edge-এ স্পর্শ করবে না; 9:16-এ মাঝের ~75% উচ্চতার ভেতরে। Pixel gap ব্যবহার করবে (বড় টেক্সটের পাশে em gap নয় — em হলে parent font-size ধরে, প্রায় শূন্য gap হয়)।
