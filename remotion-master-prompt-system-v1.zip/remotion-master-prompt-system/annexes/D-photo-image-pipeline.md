# Annex D — ফটো/ইমেজ পাইপলাইন (Sourcing → Treatment → QA)

## ১. ইমেজ উৎসের ক্রম (Fallback Chain)

1. **ইউজারের দেওয়া ছবি/অ্যাসেট** (সবসময় প্রথমে — `public/images/`)
2. **Stock ফটো** — Pexels (pexels.com) · Unsplash (unsplash.com) · Pixabay (pixabay.com)
   - বিষয়ের সঙ্গে মিল, উচ্চ রেজোলিউশন (দীর্ঘ বাহু ≥1920px), ভালো composition
   - প্রতিটি ব্যবহৃত ছবির নির্দিষ্ট asset URL, license/terms, source site এবং license যাচাইয়ের অবস্থা **`ASSETS.md`-তে** লিখবে; license নিশ্চিত না হলে ব্যবহার করবে না বা limitation জানাবে
3. **AI-generated ইমেজ** (টুল থাকলে, সীমিত ও নিয়ম মেনে — §৩)
4. **Graphic fallback** (ছবি না পেলে): gradient panel + icon + typography — কখনো broken/placeholder/লো-কোয়ালিটি ছবি নয়

Google Images থেকে যেকোনো ছবি সরাসরি ব্যবহার নিষিদ্ধ (license অযাচাই)। যে asset ব্যবহার করা হয়েছে তার নির্দিষ্ট source URL ও license/terms নথিবদ্ধ করবে; যাচাই না হলে “license verified” দাবি করবে না। asset ডাউনলোড/ব্যবহার সম্ভব না হলে তা ব্যবহৃত হয়েছে বলবে না।

## ২. Stock ফটো নির্বাচন মানদণ্ড

- বিষয়/টোন মিল; মানুষ থাকলে প্রাসঙ্গিক ও সম্মানজনক চিত্র
- ছবির মূল অংশ (মুখ/পণ্য/লোগো) crop-এ যেন না কাটে
- টেক্সট বসানোর জন্য পর্যাপ্ত negative space বা scrim স্থান
- রং যেন theme grade-এর সঙ্গে মিশে যায় (Grade overlay — Annex E)

## ৩. AI ইমেজ Consistency System (টুল থাকলে)

**Prompt skeleton lock** — এক ভিডিওর সব ছবিতে lighting/palette/style শব্দ একরকম, শুধু subject বদলাবে:

```
[subject], [style: cinematic photography | flat vector illustration | 3D render | isometric],
[lighting: soft studio light | dark moody rim light], [palette words theme color থেকে],
[mood], no text, no letters, no watermark, [aspect ratio]
```

**নিয়ম:**
- এক ভিডিওতে এক style + এক lighting + এক palette; সব ছবি **final aspect ratio-তেই**
- ইমেজে **কোনো লেখা/অক্ষর/লোগো থাকবে না** (AI টেক্সট বিকৃত করে)
- হাত/মুখ close-up ও পরিচিত ব্র্যান্ড লোগো এড়াবে (বিকৃতির ঝুঁকি); দরকার হলে stock/বাস্তব
- রেজোলিউশন যথেষ্ট; ছোট ছবি upscale করে ঝাপসা দেখাবে না
- AI ছবি ব্যবহার করা হলে `ASSETS.md`-তে "AI-generated" উল্লেখ থাকবে

## ৪. Photo Treatment Library

ছবি শুধু বসাবে না — চারপাশে professional motion design (§৪ অনুযায়ী composition):

| ট্রিটমেন্ট | কীভাবে | কোথায় |
|---|---|---|
| **Ken Burns** | scale/pan—কম মাত্রায়, composition উপযোগী হলে | full-bleed বা জীবন্ততা দরকার এমন still |
| **Gradient Scrim** | ছবির উপর linear gradient — টেক্সট পড়ার মতো contrast | text + photo |
| **Duotone** | filter + theme color overlay (soft-light) | ব্র্যান্ড টোন মিলাতে |
| **Rounded Card Frame** | borderRadius 24–32 + `1px` border + গভীর shadow | ফিচার কার্ড |
| **Mask Reveal** | আকৃতি (circle/strip/rounded rect) দিয়ে ছবি উঠে আসে (12–18f) | এন্ট্রি |
| **Mosaic Reveal** | গ্রিড টাইল stagger (4f) | এন্ট্রি/ট্রানজিশন |
| **Parallax Stack** | ২–৩টি ছবি ভিন্ন স্পিডে (0.3/0.6/1.0) | depth |
| **Before/After** | মাঝের লাইন অ্যানিমেট করে দুই ছবি তুলনা | তুলনা |
| **Polaroid/Print Stack** | হালকা রোটেশন (±3°) + স্ট্যাক + shadow | স্টোরি |
| **Photo + HUD** | ছবির উপর grid/লাইন/লেবেল annotation | টেকনিক্যাল |
| **Cutout Collage** | ব্যাকগ্রাউন্ড-ছাড়া subject + shape layer | এনার্জেটিক |
| **Film Border** | সাদা মার্জিন + grain | সিনেমাটিক |
| **Text Window** | টেক্সটের ভেতর ছবি (background-clip) | হুক |
| **Split Screen** | অর্ধেক ছবি + অর্ধেক টেক্সট/গ্রাফিক (animated divide) | explainer |
| **Layered Panels** | ছবি ২-স্তরে কেটে সামনে/পেছনে (2.5D) | depth/parallax |

## ৫. ইমেজ QA (render-এর পর যাচাই)

- [ ] কোনো ছবি stretch/বিকৃত নয় (`objectFit: cover` + focal point)
- [ ] মুখ/লোগো/গুরুত্বপূর্ণ অংশ crop-এ কাটেনি
- [ ] broken/missing image নেই (frame inspect-এ দেখা)
- [ ] টেক্সট–ছবি contrast পর্যাপ্ত (scrim আছে)
- [ ] ছবি–graphics সামঞ্জস্যপূর্ণ; একটি অপরটিকে ঢাকেনি
- [ ] Tutorial থাকলে interface/controls স্পষ্ট দেখা যায়
- [ ] প্রতিটি ছবির source + license `ASSETS.md`-তে
