# Annex J — Master QA Checklist (ডেলিভারির আগে — প্রতিটি ভিডিওতে)

> এই checklist চালাও — প্রতিটি ধাপ বাস্তবে করা হয়েছে মনে হলেই tick। কোনো ধাপ করা হয়নি হলে তা ডেলিভারি নোটে স্পষ্টে লিখবে — সফল দাবি করবে না।

## A. Pre-flight (Setup)
- [ ] Node.js / npm version পরীক্ষিত
- [ ] Dependency compatibility: `remotion` ও `@remotion/cli` version মেলে, React compatibility যাচাই; clean install (`npm ci` যখন lockfile আছে) সফল
- [ ] `package.json` scripts — `studio` ও `render` script সত্যিকারের entry/composition-এ যুক্ত; TypeScript project-এ TypeScript ও type dependencies আছে
- [ ] `package-lock.json` আছে; পুনরুৎপাদনযোগ্য dependency install পরীক্ষা হয়েছে
- [ ] Remotion entry point (`src/index.ts`) ও Composition ID (`Main`) সঠিক
- [ ] Missing imports / syntax errors / missing modules নেই
- [ ] Missing assets নেই; image/audio/font path সঠিক (`staticFile()`)
- [ ] Windows path compatibility (forward slash; drive letter সমস্যা নেই)
- [ ] Font loading — licensed local font file + CSS `@font-face`/সঠিক path বা নির্ভরযোগ্য fallback; offline test-এ **বাংলা যুক্তাক্ষর/কার/রেফ/baseline rendering** ঠিক
- [ ] Scene timing, fps (30/60), output resolution সঠিক
- [ ] `theme.ts` ছাড়া কোথাও inline hex color/easing নেই

## B. Content Integrity
- [ ] Transcript-এর সম্পূর্ণ অংশ বিশ্লেষিত; কোনো অংশ বাদ পড়েনি
- [ ] Scene plan ↔ transcript consistency (অর্থ/ক্রম অক্ষুণ্ণ)
- [ ] কোনো কল্পিত তথ্য/সংখ্যা/দাবি/slogan/placeholder নেই
- [ ] সম্পূর্ণ transcript subtitle হিসেবে নেই; শুধু headline/keyword/label/visual
- [ ] Watermark/অযাচিত branding নেই
- [ ] 2D cartoon human নেই; emoji-as-icon নেই

## C. টাইমিং ও SRT (থাকলে)
- [ ] SRT থাকলে start/end → frame conversion নির্ভুল (fps অনুযায়ী, deterministic); না থাকলে audio duration/estimate নথিভুক্ত
- [ ] SRT থাকলে কোনো cue-এর লেখা নির্ধারিত start-এর আগে সম্পূর্ণ দেখানো হয়নি
- [ ] cue বদলানোর পর পুরানো লেখা/visual অকারণে স্থির নেই
- [ ] প্রযোজ্য gap/overlap/duration অমিল শনাক্ত ও নথিভুক্ত
- [ ] শেষে অপ্রয়োজনীয় blank frame/frozen scene নেই; duration ↔ SRT/audio/ঘোষিত estimate মেলে

## D. Visual Frame Inspection (বাধ্যতামূলক — চোখে দেখা)
- [ ] মূল ফ্রেমগুলো `npx remotion still` দিয়ে render করে দেখা হয়েছে
- [ ] Spacing bug নেই (em gap, margin); বড় টেক্সটের পাশে pixel gap
- [ ] টেক্সট frame edge-এ কাটছে না; 9:16 safe zone মানা
- [ ] Element entrance-এর আগে/exit-এর পর দেখা যাচ্ছে না (clamp সঠিক)
- [ ] ব্যবহৃত layer-এর ক্রম সঠিক; অপ্রয়োজনীয় layer/texture নেই
- [ ] Focal point, contrast ও color hierarchy পরিষ্কার; একাধিক accent/glow থাকলে পাঠযোগ্যতা অক্ষুণ্ণ
- [ ] Background ও post-treatment বিষয়/পাঠযোগ্যতার উপযোগী (প্রয়োজন হলে flat/minimal)
- [ ] Still-এ motion treatment কেবল উপযুক্ত হলে; crop/focal point ঠিক
- [ ] Exits animated ও এন্ট্রান্সের চেয়ে দ্রুত
- [ ] সমস্যা পেলে ঠিক করে **পুনরায় render → আবার দেখা** হয়েছে

## E. ছবি/অ্যাসেট
- [ ] কোনো broken/missing image নেই; stretch/দুর্বল crop নেই
- [ ] মুখ/লোগো/গুরুত্বপূর্ণ অংশ কাটেনি
- [ ] প্রতিটি ছবির source + license `ASSETS.md`-তে
- [ ] Logo বিকৃত/পুনঃসৃষ্টি করা হয়নি

## F. Tutorial (প্রযোজ্য হলে — Annex G)
- [ ] প্রতিটি ধাপ transcript-এর সঙ্গে মিলে; কোনো ধাপ বাদ পড়েনি
- [ ] সঠিক button/option/field দেখানো হয়েছে (Annex G honesty tier মানা)
- [ ] Cursor সঠিক জায়গায় click করছে; UI state ঠিক সেখানে বদলাচ্ছে
- [ ] UI continuity আছে (আগের ধাপের page/tab/state ধরে রাখা)
- [ ] Annotation পড়ার মতো; UI element ঢাকছে না
- [ ] শুরু থেকে শেষ অনুসরণযোগ্য; দর্শক দেখে কাজটি করতে পারবে
- [ ] Recreation/uncertainty থাকলে delivery note-এ উল্লেখ আছে

## G. Audio
- [ ] SFX peak/duration/clipping যাচাই; level match
- [ ] SFX visual-এর ২–৩f আগে; অতিরিক্ত loud নয়
- [ ] VO থাকলে কিছুই তাকে ঢাকছে না; না থাকলে "audio sync যাচাই হয়েছে" দাবি করা হয়নি
- [ ] Audio asset source/license নোট আছে

## H. Final Render QA (শুধু MP4 render করা হলে)
- [ ] Rendered video শুরু থেকে শেষ দেখা হয়েছে
- [ ] Text clipping, বাংলা অক্ষর, broken image, transition, animation timing ঠিক
- [ ] Resolution ও fps সঠিক; শেষে blank frames নেই
- [ ] Tutorial থাকলে ধাপ সঠিক ক্রমে; গুরুত্বপূর্ণ ধাপ পড়ার মতো সময় পেয়েছে
- [ ] MP4 render না হলে এই QA সম্পন্ন বলে tick নয়; preview/still-frame checks আলাদাভাবে নথিভুক্ত

## I. Delivery
- [ ] ZIP (node_modules ছাড়া) তৈরি; extract করে README অনুযায়ী চলবে
- [ ] README.md (PowerShell: install / studio / render / output / error handling; studio command entry file-সহ)
- [ ] ASSETS.md (প্রতিটি ব্যবহৃত asset-এর নির্দিষ্ট source + license; যাচাই না হলে স্পষ্ট নোট)
- [ ] ৩টি কমান্ড (আসল path/ID সহ — placeholder নয়)
- [ ] সব পরীক্ষা যা বাস্তবে সম্পন্ন হয়েছে তা তালিকাবদ্ধ; limitation/missing asset স্পষ্ট
- [ ] কোনো command চালানো সম্ভব না হলে সেটি জানানো হয়েছে
