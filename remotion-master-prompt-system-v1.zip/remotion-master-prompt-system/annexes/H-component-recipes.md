# Annex H — Component Recipes (কপি-পেস্ট কোড লাইব্রেরি)

> সব component `theme` import করবে (`src/theme.ts`)। `useCurrentFrame()` / `useVideoConfig()` / `interpolate` / `spring` remotion থেকে। **কোনো `interpolate()` linear নয়; সবসময় clamp।** কোডে inline hex/easing নয়।

## 1. Premium entrance (কাজের ঘোড়া)

```tsx
const Entrance: React.FC<{delay?: number; children: React.ReactNode}> =
({ delay = 0, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  return (
    <div style={{
      opacity: p,
      transform: `translateY(${interpolate(p, [0, 1], [40, 0])}px)
                  scale(${interpolate(p, [0, 1], [0.94, 1])})`,
    }}>{children}</div>
  );
};
```
Bezier দরকার হলে (নিয়ন্ত্রিত slide):
```tsx
const x = interpolate(frame, [0, 25], [60, 0], {
  easing: theme.ease.out,
  extrapolateLeft: "clamp", extrapolateRight: "clamp", // সবসময় দুটোই
});
```

## 2. Staggered children
```tsx
{items.map((item, i) => <Entrance key={i} delay={start + i * 4}>{item}</Entrance>)}
```
offset: শব্দ 3f · কার্ড/তালিকা 4–5f · বড় ব্লক 6f।

## 3. Word-by-word reveal (বাংলা-সেফ — space split)
```tsx
const WordReveal: React.FC<{text: string; delay?: number; per?: number;
  style?: React.CSSProperties}> = ({ text, delay = 0, per = 3, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "0.26em", ...style }}>
      {text.split(" ").map((word, i) => {
        const p = spring({ frame: frame - delay - i * per, fps,
          config: theme.spring.snappy });
        return (
          <span key={i} style={{
            display: "inline-block", opacity: p,
            transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px)`,
          }}>{word}</span>
        );
      })}
    </div>
  );
};
```
GOTCHA: বড় টেক্সট ব্লকের পাশে flex row-তে `gap` pixel-এ (যেমন 42) — em নয় (em = parent font-size, প্রায় শূন্য gap হয়)।

## 4. Background mesh (ফ্ল্যাট নয়)
```tsx
const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50, d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1200, height: 1200,
        borderRadius: "50%", top: -450, left: -300 + d1, filter: "blur(50px)",
        background: `radial-gradient(circle, ${theme.colors.primary}33, transparent 62%)` }}/>
      <div style={{ position: "absolute", width: 900, height: 900,
        borderRadius: "50%", bottom: -400, right: -250 - d2, filter: "blur(70px)",
        background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)` }}/>
    </AbsoluteFill>
  );
};
```

## 5. Color grade overlay (content-এর উপরে, grain-এর নিচে)
```tsx
const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary,
      mixBlendMode: "soft-light", opacity: 0.18 }}/>
    <AbsoluteFill style={{ background:
      "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.2))" }}/>
  </AbsoluteFill>
);
```
Opacity: light theme 0.10–0.15, dark 0.18–0.25।

## 6. Procedural grain (asset ছাড়া)
```tsx
const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none",
    backgroundImage: noise, backgroundSize: "220px",
    backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
    opacity: 0.05, mixBlendMode: "multiply" }}/>; // dark theme-এ "overlay"
};
```

## 7. Vignette (সবচেয়ে উপরের layer)
```tsx
const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background:
    "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.22) 100%)" }}/>
);
```

## 8. Ken Burns (ঐচ্ছিক treatment — উপযুক্ত still-এ)
```tsx
const KenBurns: React.FC<{src: string; zoomTo?: number}> = ({ src, zoomTo = 1.1 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const scale = interpolate(frame, [0, durationInFrames], [1, zoomTo],
    { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const pan = interpolate(frame, [0, durationInFrames], [0, -25],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return <Img src={staticFile(src)} style={{ width: "100%", height: "100%",
    objectFit: "cover", transform: `scale(${scale}) translateX(${pan}px)` }}/>;
};
```
যে shot-এ motion composition-কে সাহায্য করে সেখানে ব্যবহার করো; document/UI-র স্থির পাঠযোগ্যতা দরকার হলে zoom/pan বাদ দাও। পরপর শটে zoom-in/zoom-out alternate করা যেতে পারে। Rounded card-এ মাস্ক: `borderRadius: 32, overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)", boxShadow: "0 40px 80px -20px rgba(0,0,0,0.6)"`।

## 9. Animated counter
```tsx
const value = interpolate(
  spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60 } }),
  [0, 1], [0, target], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
<span style={{ fontVariantNumeric: "tabular-nums" }}>{value.toFixed(1)}%</span>
```
`tabular-nums` ডিজিট বদলালে jitter রোধ করে। **সংখ্যা সবসময় স্ক্রিপ্টের — কল্পিত নয়।**

## 10. Spark / radial logo mark
```tsx
const rays = 12;
{Array.from({ length: rays }).map((_, i) => {
  const p = spring({ frame: frame - delay - i * 1.2, fps,
    config: theme.spring.snappy });
  return <div key={i} style={{ position: "absolute", left: "50%", top: "50%",
    width: size * 0.085, height: size * 0.46 * p, background: theme.colors.primary,
    borderRadius: size, transformOrigin: "50% 0%",
    transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.07}px)` }}/>
})}
```
কনটেইনারে bouncy scale + smooth rotation (−120° থেকে) + `filter: drop-shadow(0 0 ${size*0.25}px ${theme.colors.glow})`।

## 11. Exits — এন্ট্রান্সের চেয়ে দ্রুত
```tsx
const exitY = interpolate(frame, [durationInFrames - 12, durationInFrames - 2],
  [0, -42], { easing: theme.ease.in,
  extrapolateLeft: "clamp", extrapolateRight: "clamp" });
const exitO = interpolate(frame, [durationInFrames - 12, durationInFrames - 2],
  [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
```
প্রতিটি visible element বা scene wrapper-এ প্রয়োগ।

## 12. Idle breathing (ঐচ্ছিক micro-motion)
```tsx
const breathe = 1 + Math.sin(frame / 22) * 0.015;
const float = Math.sin(frame / 30) * 3;
const drift = interpolate(frame, [0, 300], [0, -20],
  { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
```

## 13. Parallax depth (৩ স্তর)
```tsx
const x = interpolate(frame, [0, 90], [0, -120],
  { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
<Bg style={{ transform: `translateX(${x * 0.3}px)` }}/>
<Mid style={{ transform: `translateX(${x * 0.6}px)` }}/>
<Fg style={{ transform: `translateX(${x}px)` }}/>
```

## 14. Transitions
`@remotion/transitions`:
```tsx
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { slide } from "@remotion/transitions/slide";
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={90}><A/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({ direction: "from-right" })}
    timing={linearTiming({ durationInFrames: 12 })}/>
  <TransitionSeries.Sequence durationInFrames={150}><B/></TransitionSeries.Sequence>
</TransitionSeries>
```
`linearTiming` transition-এর অগ্রগতি নিয়ন্ত্রণ করে; এটি `interpolate()`-এর `easing: Easing.linear` ব্যবহারের সমতুল্য নয়। Softer/physics-based transition চাইলে `springTiming` বা উপযুক্ত presentation ব্যবহার করো.

`linearTiming` transition-এর অগ্রগতি নিয়ন্ত্রণ করে; এটি `interpolate()`-এর `easing: Easing.linear` ব্যবহারের সমতুল্য নয়। Softer/physics-based transition চাইলে `springTiming` বা উপযুক্ত presentation ব্যবহার করো।

Hand-rolled (৮–১৪f):
- **Whip pan**: bg 6f-এ 1500px + `filter: blur(8px)`; cut মাঝ-whip-এ।
- **Scale-through**: A scale 1.3 + fade, B 0.8→1 নিচে।
- **Mask wipe**: brand-color আকৃতি সুইপ; পেছনে cut।

## 15. Motion blur (>30px/frame মুভে)
```tsx
import { Trail } from "@remotion/motion-blur";
<Trail layers={4} lagInFrames={0.4}><FastThing/></Trail>
```

## 16. Audio + SFX sync
```tsx
import { Audio, Sequence, staticFile } from "remotion";
<Audio src={staticFile("sfx/music.mp3")} volume={0.25}/>
<Sequence from={Math.max(0, entranceFrame - 3)}>  {/* visual ল্যান্ডের 2-3f আগে; negative frame নয় */}
  <Audio src={staticFile("sfx/whoosh_soft_01.wav")} volume={0.3}/>
</Sequence>
```
Beat-এ cut: `framesPerBeat = fps * 60 / BPM`।

## 17. Audio ছাড়া SRT-driven phrase reveal (ডিফল্ট পদ্ধতি)
```tsx
// cue-এর সময়সীমার মধ্যে লাইন/phrase ধরে reveal — শব্দ timestamp না থাকলে word-by-word নয়
const cue = { start: 90, end: 150, lines: ["প্রথম লাইন", "দ্বিতীয় লাইন"] };
{cue.lines.map((line, i) => {
  const lineStart = cue.start + i * ((cue.end - cue.start) / cue.lines.length);
  return <LineMaskRise key={i} text={line} delay={lineStart}/>;
})}
```
শব্দ-স্তরের reveal শুধু নির্ভরযোগ্য word-level timestamp (Whisper/`@remotion/captions`) থাকলেই।

## 18. Text Window (টেক্সটের ভেতর ছবি)
```tsx
<div style={{
  fontSize: 120, fontWeight: 800,
  backgroundImage: `url(${staticFile("images/hero.jpg")})`,
  backgroundSize: "cover", backgroundPosition: `${50 + panX}% 50%`,
  WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
}}>{word}</div>
```

## 19. Highlight sweep (pill/underline)
```tsx
const sweep = interpolate(frame, [delay, delay + 12], [0, 1],
  { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
<div style={{ position: "relative", display: "inline-block" }}>
  {word}
  <div style={{ position: "absolute", left: 0, bottom: 4, height: 10,
    width: `${sweep * 100}%`, background: theme.colors.primary, opacity: 0.35,
    borderRadius: 8 }}/>
</div>
```

## 20. Icon draw-on (Annex C)
```tsx
const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
<svg viewBox="0 0 24 24" width={40} height={40} fill="none"
  stroke={theme.colors.text} strokeWidth={2} strokeLinecap="round">
  <path d="M4 12l5 5L20 6"
    strokeDasharray={30} strokeDashoffset={30 * (1 - p)} />
</svg>
```
