# Annex I — SFX Synthesis Recipes ও Audio QA

> ইউজার SFX দিলে সেগুলোই ব্যবহার করবে (`public/sfx/`)। না দিলে নিচের রেসিপি অনুযায়ী Node script দিয়ে 16-bit WAV সিন্থেসাইজ করবে — ডাউনলোড ছাড়াই, deterministic।

## ১. সাউন্ড কিট (৫–৭টি — সারা ভিডিওতে সীমিত সেট)

| ফাইল | ইভেন্ট | রেসিপি |
|---|---|---|
| `whoosh_soft_01.wav` | টেক্সট/শিরোনাম এন্ট্রি, ট্রানজিশন | band-pass noise sweep + fade in/out (≤0.8s) |
| `pop_soft_01.wav` | কার্ড/UI reveal | দ্রুত নিচে নামা pitch সহ sine + ছোট envelope (0.1–0.25s) |
| `click_crisp_01.wav` | বাটন, টিক, চেকমার্ক | high-pass করা ছোট noise burst (0.05–0.12s) |
| `chime_pluck_01.wav` | লোগো reveal | নরম ওভারটোনসহ ছোট decay sine/triangle (0.2–0.4s) |
| `thud_soft_01.wav` | হুক/মূল বার্তা | ছোট low sine thump (60–90Hz), দ্রুত decay (0.15s) |
| `tick_soft_01.wav` | কাউন্টার | খুব ছোট click (pop-এর চেয়ে ছোট) |
| `riser_soft_01.wav` | (ঐচ্ছিক) হুক/শেষের আগে | noise/pitch ধীরে উপরে, শেষে ছোট |

**সব সাউন্ডে হালকা low-pass + খুব ছোট reverb।** সাধারণ sine/square বীপ নয়। কার্টুনি/গেমি/হাই-পিচ/ধাতব/কর্কশ/ভারী ইমপ্যাক্ট নয়।

## ২. মান স্পেক

| প্যারামিটার | মান |
|---|---|
| দৈর্ঘ্য | 0.1–0.5s (whoosh সর্বোচ্চ 0.8s) |
| Envelope | নরম attack, দ্রুত decay, লম্বা tail নয় |
| Volume | 0.2–0.35 (সংযত); VO ঢাকবে না |
| Peak | ≈ −1dB ceiling; **clipping নয়** |
| ফরম্যাট | 16-bit WAV, 44.1kHz (বা 48kHz) |
| নামকরণ | `public/sfx/<type>_<mood>_01.wav` |

## ৩. ব্যবহার নিয়ম

- একই ইভেন্টে একই সাউন্ড; পরপর একই হলে সামান্য pitch/volume variation
- **শুধু** গুরুত্বপূর্ণ এন্ট্রি, কার্ড/লোগো reveal ও সিন ট্রানজিশনে — প্রতি staggered item-এ নয়
- SFX visual-এর **২–৩ frame আগে** শুরু হবে
- প্রতিটি ট্রানজিশনে SFX বাধ্যতামূলক নয়
- অপ্রয়োজনীয় background music/sound নয়; মিউজিক বেড ঐচ্ছিক (থাকলে 0.2–0.3)

## ৪. Audio QA (তৈরির পরে — প্রতিটি ফাইল)

- [ ] দৈর্ঘ্য সীমার ভেতরে
- [ ] peak লেভেল পরিমাপ করা হয়েছে; clipping নেই
- [ ] সব সাউন্ড প্রায় একই ধারায় মিলিয়ে দেওয়া (level match)
- [ ] কম্পোজিশনে সঠিক frame-এ যুক্ত; ২–৩f আগে শুরু
- [ ] ভয়েসওভার থাকলে সব সাউন্ড 6–10dB নিচে
- [ ] সোর্স/লাইসেন্স নোট `ASSETS.md`-তে (সিন্থ করা হলে "synthesized in-project")

## ৫. Remotion-এ যুক্ত করা

```tsx
import { Audio, Sequence, staticFile } from "remotion";

<Sequence from={entranceFrame - 3}>
  <Audio src={staticFile("sfx/whoosh_soft_01.wav")} volume={0.7} />
</Sequence>
```
SFX ফাইল `public/sfx/`-এ — Studio প্রিভিউতেও শোনা যাবে। কম্পোজিশনে সব SFX `<Sequence>`-এ নির্দিষ্ট frame-এ, কখনো শুধু ফাইল রেখে দেওয়া নয়।
